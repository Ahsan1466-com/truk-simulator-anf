TRUK INDONESIA SIMULATOR — NMR71

Isi:
- index.html = game
- NMR71 UPDATE V2.obj = model truk dari file kamu
- JALANKAN_GAME.bat = menjalankan game di localhost

Kontrol PC:
W/S atau panah = gas/rem
A/D atau panah = belok
SPACE = rem tangan
M = ganti muatan: kosong / 4 ton / 8 ton

Kontrol HP: tombol di layar.

Map bernuansa Indonesia: jalan desa, sawah, rumah, warung, pohon kelapa, dan pegunungan.
Efek oleng dipengaruhi kecepatan, belokan, dan berat muatan.

Catatan: jalankan lewat JALANKAN_GAME.bat agar OBJ bisa dibaca browser.
